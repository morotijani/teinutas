# teinutas
Member registration, dues payment and news feed built for TEIN - UTAS
