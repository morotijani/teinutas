<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>APP.TEIN</title>
    <link href="<?= PROOT; ?>dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= PROOT; ?>dist/css/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="<?= PROOT; ?>dist/css/tein.css">
</head>
<body>