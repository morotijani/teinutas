<?php

	define('BASEURL', $_SERVER['DOCUMENT_ROOT'].'/teinutas/');
	
	define('PROOT', '/teinutas/');

	define('PAYSTACK_TEST_SECRET_KEY', 'sk_test_0f0bbb8b6ad943d9676e2ca3577d342d81195c0e');
	define('PAYSTACK_PUBLIC_KEY', 'pk_test_24de52be03ae0061b5fccd880c02c520f3e60813');
	

?>
